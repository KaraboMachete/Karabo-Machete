# Karabo's Website

A Pen created on CodePen.io. Original URL: [https://codepen.io/Machete-Susan/pen/LYwRgEj](https://codepen.io/Machete-Susan/pen/LYwRgEj).

